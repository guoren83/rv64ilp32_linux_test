#!/bin/sh

export PATH="../bin/:${PATH}"

exec qemu-system-riscv64 -cpu rv64 -M virt -m 128m -nographic -bios ../fw_dynamic.bin -kernel $1 -drive file=$2,format=raw,id=hd0 -device virtio-blk-device,drive=hd0 -append "rootwait root=/dev/vda ro console=ttyS0 earlycon=sbi norandmaps no5lvl no4lvl"
